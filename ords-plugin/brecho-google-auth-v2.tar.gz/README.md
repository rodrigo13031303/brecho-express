# Brechó Express Google Auth — ORDS Plugin

Compatibility probe for Oracle REST Data Services 25.4 and Java 17.

The first increment exposes:

```text
GET /ords/brechoexpress/api/v1/auth/social/google/health
```

It verifies that ORDS discovers the plugin and injects a connection mapped to
the `BRECHOEXPRESS` schema. It does not process tokens or authenticate users.

## Server build

The server must contain the official ORDS 25.4 plugin libraries under:

```text
/opt/ords/examples/plugins/lib
```

Build:

```bash
chmod +x build.sh
./build.sh
```

The output is:

```text
built/brecho-google-auth.jar
```

Deployment and ORDS restart are intentionally separate operational steps.
