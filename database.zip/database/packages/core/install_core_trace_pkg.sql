WHENEVER SQLERROR EXIT SQL.SQLCODE

@@core_trace_pkg.pks
@@core_trace_pkg.pkb

SHOW ERRORS PACKAGE core_trace_pkg
SHOW ERRORS PACKAGE BODY core_trace_pkg

EXIT SUCCESS
